# How to Use the load-tester

1. Install k6 `brew install k6`
2. Run `k6 run script.js`
