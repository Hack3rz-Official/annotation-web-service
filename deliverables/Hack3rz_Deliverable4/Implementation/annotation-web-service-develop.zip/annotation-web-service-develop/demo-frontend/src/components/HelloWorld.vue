<script setup>
defineProps({
  msg: {
    type: String,
    required: true
  }
})
</script>

<template>
  <div>
    
  </div>
</template>

<style scoped>

</style>
