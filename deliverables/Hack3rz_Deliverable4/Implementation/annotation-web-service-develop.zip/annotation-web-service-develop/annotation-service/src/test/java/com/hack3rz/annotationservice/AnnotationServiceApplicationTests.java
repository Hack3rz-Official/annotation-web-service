package com.hack3rz.annotationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnnotationServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
