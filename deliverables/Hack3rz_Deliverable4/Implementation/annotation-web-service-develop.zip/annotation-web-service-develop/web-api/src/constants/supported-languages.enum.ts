export enum SupportedLanguage {
  JAVA = 'java',
  KOTLIN = 'kotlin',
  PYTHON = 'python3',
}
